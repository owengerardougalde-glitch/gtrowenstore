export default {
  async fetch(request, env) {
    const corsHeaders = {
      "Access-Control-Allow-Origin": "https://gtrowen.store",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);
    if (url.pathname !== "/api/ff/verify" || request.method !== "GET") {
      return new Response("Not found", { status: 404, headers: corsHeaders });
    }

    const id = url.searchParams.get("id");
    if (!id || !/^\d{5,20}$/.test(id)) {
      return Response.json({ ok: false, error: "ID_INVALID" }, { status: 400, headers: corsHeaders });
    }
    if (!env.VOLSEVER_API_KEY) {
      return Response.json({ ok: false, error: "API_KEY_MISSING" }, { status: 500, headers: corsHeaders });
    }

    try {
      const response = await fetch(
        `https://gate.volsever.com/proxy/api/game/free-fire-global?id=${encodeURIComponent(id)}`,
        { headers: { "X-API-Key": env.VOLSEVER_API_KEY, "Accept": "application/json" } }
      );
      const result = await response.json().catch(() => null);
      const username = result?.data?.username || result?.username || "";
      const region = result?.data?.region || result?.region || "";
      const found = response.ok && result?.status === true && !!username;

      return Response.json(
        found
          ? { ok: true, username, region }
          : { ok: false, error: "NOT_FOUND", message: result?.message || "No se pudo validar el ID" },
        { status: found ? 200 : (response.ok ? 404 : response.status), headers: corsHeaders }
      );
    } catch (error) {
      return Response.json({ ok: false, error: "UPSTREAM_ERROR" }, { status: 502, headers: corsHeaders });
    }
  }
};
